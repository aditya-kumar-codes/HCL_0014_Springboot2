package com.example.hclassesment2.model;

public class Product {
    int pid;
    String pname;
    String Description;
    double price;
    int Quantity;
    String catogry;




}
