package com.example.hclassesment2;

import com.example.hclassesment2.service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import java.sql.SQLOutput;

@Component
@org.springframework.web.bind.annotation.RestController
public class RestController {

    @Autowired
    CustomerService service;

    @GetMapping("/")
    public void show()
    {
        System.out.println("welcome to shopp app");
    }

    @GetMapping("api/customer")
    public void getallCustomer()
    {
        System.out.println("all customer");
        service.showallCustomer();

    }

    @PostMapping("/api/customer/register")
    public void addcustomer()
    {
        System.out.println("cutomer added");
        service.addCustomer();

    }

}
