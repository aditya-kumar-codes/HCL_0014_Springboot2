package com.example.hclassesment2.service;

import com.example.hclassesment2.model.Customer;
import com.example.hclassesment2.repo.CustomerRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CustomerService {
    @Autowired
    CustomerRepo cr;
    Customer customer;

    public void showallCustomer()
    {
        cr.getallCustomer(customer);
    }


    public void addCustomer() {
        cr.addCustomer(customer);
    }
}
