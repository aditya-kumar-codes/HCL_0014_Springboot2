package com.example.hclassesment2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HclAssesmentApplication {

    public static void main(String[] args) {

        SpringApplication.run(HclAssesmentApplication.class, args);
        System.out.println("hello world");
    }

}
