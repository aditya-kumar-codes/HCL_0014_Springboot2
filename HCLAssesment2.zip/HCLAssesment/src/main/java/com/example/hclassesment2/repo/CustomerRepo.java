package com.example.hclassesment2.repo;

import com.example.hclassesment2.model.Customer;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Repository
public class CustomerRepo {
    List<Customer>cr=new ArrayList<>();
    Customer customer;
    //customer.setCustomerid(1);

    public List<Customer> getallCustomer(Customer customer)
    {
        return null;
    }

    public void addCustomer(Customer customer) {
        cr.add(customer);
    }

}
